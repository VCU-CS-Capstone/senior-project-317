/** Automatically generated file. DO NOT MODIFY */
package com.jaalee.BeaconDemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}