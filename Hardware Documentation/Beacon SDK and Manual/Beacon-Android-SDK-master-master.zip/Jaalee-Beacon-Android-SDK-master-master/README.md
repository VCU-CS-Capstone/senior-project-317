Jaalee-Beacon-Android-SDK-master
============================

## Overview ##

It allows for:
- beacon ranging (scan beacons and optionally filters them by their values)
- beacon monitoring (monitors regions for those devices that have entered/exited a region)
- beacon characteristic reading and writing (proximity UUID, major & minor values, broadcasting power, advertising interval), see BeaconConnection class and demos in the source code

Dear JAALEE SDK developer.

We are happy to share with you our latest Beacon SDK for Android.

You can email us with any question or problem you are having, and we will try hard to reply asap. Email: dev@jaalee.com

If you need beacons in larger quantities, please contact our sales dept: sales@jaalee.com

Our Team：[JAALEE](http://www.jaalee.com/)

JAALEE Website：[http://www.jaalee.com/](http://www.jaalee.com/)

Contact Us：service@jaalee.com
