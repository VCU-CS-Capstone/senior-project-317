/** Automatically generated file. DO NOT MODIFY */
package com.jaalee.ibeaconreference;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}