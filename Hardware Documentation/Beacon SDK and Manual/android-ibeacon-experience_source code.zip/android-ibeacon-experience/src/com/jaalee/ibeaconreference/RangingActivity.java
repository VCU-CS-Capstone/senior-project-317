/**
 * Jaalee Inc
 * http://www.jaalee.com/
 * Created by jaalee on 14-2-18.
 * Copyright (c) 2013 jaalee. All rights reserved.
 */

package com.jaalee.ibeaconreference;

import java.util.Collection;

import com.jaalee.ibeacon.IBeacon;
import com.jaalee.ibeacon.IBeaconConsumer;
import com.jaalee.ibeacon.IBeaconManager;
import com.jaalee.ibeacon.RangeNotifier;
import com.jaalee.ibeacon.Region;

import android.app.Activity;

import android.os.Bundle;
import android.os.RemoteException;
import android.widget.EditText;

public class RangingActivity extends Activity implements IBeaconConsumer {
    protected static final String TAG = "RangingActivity";
    private IBeaconManager iBeaconManager = IBeaconManager.getInstanceForApplication(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_ranging);
        iBeaconManager.bind(this);
    }
    @Override 
    protected void onDestroy() {
        super.onDestroy();
        iBeaconManager.unBind(this);
    }
    @Override 
    protected void onPause() {
    	super.onPause();
    }
    @Override 
    protected void onResume() {
    	super.onResume();
    }

    @Override
    public void onIBeaconServiceConnect() {
        iBeaconManager.setRangeNotifier(new RangeNotifier() {
        @Override 
        public void didRangeBeaconsInRegion(Collection<IBeacon> iBeacons, Region region) {
            if (iBeacons.size() > 0) {
            	EditText editText = (EditText)RangingActivity.this
						.findViewById(R.id.rangingText);
            	logToDisplay("The first iBeacon I see is about "+iBeacons.iterator().next().getAccuracy()+" meters away.");            	
            }
        }

        });

        try {
            iBeaconManager.startRangingBeaconsInRegion(new Region("ebefd083-70a2-47c8-9837-e7b5634df524", null, null, null));
        } catch (RemoteException e) {   }
    }
    private void logToDisplay(final String line) {
    	runOnUiThread(new Runnable() {
    	    public void run() {
    	    	EditText editText = (EditText)RangingActivity.this
    					.findViewById(R.id.rangingText);
    	    	editText.append(line+"\n");            	
    	    }
    	});
    }
}
