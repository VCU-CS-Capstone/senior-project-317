/**
 * http://www.jaalee.com/
 * Jaalee, Inc.
 * This project is for developers, not for commercial purposes.
 * Special thanks to the open-source support provided by Radius Networks
 */
package com.jaalee.ibeacon.service;

import java.util.HashSet;
import java.util.Set;


import com.jaalee.ibeacon.IBeacon;

public class RangeState {
	private Callback callback;
	private Set<IBeacon> iBeacons = new HashSet<IBeacon>();
	
	public RangeState(Callback c) {
		callback = c;		
	}
	
	public Callback getCallback() {
		return callback;
	}
	public void clearIBeacons() {
		iBeacons.clear();
	}
	public Set<IBeacon> getIBeacons() {
		return iBeacons;
	}
	public void addIBeacon(IBeacon iBeacon) {
		iBeacons.add(iBeacon);
	}
	

}
