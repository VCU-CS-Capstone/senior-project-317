/**
 * http://www.jaalee.com/
 * Jaalee, Inc.
 * This project is for developers, not for commercial purposes.
 * Special thanks to the open-source support provided by Radius Networks
 */
package com.jaalee.ibeacon;

import java.util.Collection;
/**
 * This interface is implemented by classes that receive iBeacon ranging notifications
 * 
 * @see IBeaconManager#setRangeNotifier(RangeNotifier notifier)
 * @see IBeaconManager#startRangingBeaconsInRegion(Region region)
 * @see Region
 * @see IBeacon
 * 
 */
public interface RangeNotifier {
	/**
	 * Called once per second to give an estimate of the distance to visible iBeacons
	 * @param iBeacons a collection of <code>IBeacon<code> objects that have been seen in the past second
	 * @param region the <code>Region</code> object that defines the criteria for the ranged iBeacons
	 */
	public void didRangeBeaconsInRegion(Collection<IBeacon> iBeacons, Region region);
}
