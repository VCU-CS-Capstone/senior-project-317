//
//  JLEProximityDemo.h
//  Example
//
//  Created by jaalee on 14-4-23.
//  Copyright (c) 2014年 jaalee. All rights reserved.
//

#import "ViewController.h"

@interface JLEProximityDemo : ViewController

@property (weak, nonatomic) IBOutlet UILabel *mStateShow;
@property (weak, nonatomic) IBOutlet UIImageView *mImageView;
@end
