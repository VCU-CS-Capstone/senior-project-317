//
//  BeaconStateViewController.h
//  Example
//
//  Created by jaalee on 15/5/25.
//  Copyright (c) 2015年 jaalee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"

@interface BeaconStateViewController : BaseViewController

@end
