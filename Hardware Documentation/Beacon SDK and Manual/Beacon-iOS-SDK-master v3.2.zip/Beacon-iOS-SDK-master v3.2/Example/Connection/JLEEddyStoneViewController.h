//
//  EddyStoneViewController.h
//  Example
//
//  Created by jaalee on 15/8/29.
//  Copyright (c) 2015年 jaalee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ViewController.h"

@interface EddyStoneViewController : ViewController

@end
