//
//  EddyStoneViewController.m
//  Example
//
//  Created by jaalee on 15/8/29.
//  Copyright (c) 2015年 jaalee. All rights reserved.
//

#import "JLEEddyStoneViewController.h"
#import "ESSBeaconScanner.h"
#import "ESSEddystone.h"

@interface EddyStoneViewController ()<ESSBeaconScannerDelegate,UIScrollViewDelegate, UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *EddyStoneTableView;
@property (nonatomic)        NSMutableArray *mEddystoneBeaconDeviceList;
@property (nonatomic)        ESSBeaconScanner *scanner;
@end

@implementation EddyStoneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    _mEddystoneBeaconDeviceList = [[NSMutableArray alloc] init];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    _scanner = [[ESSBeaconScanner alloc] init];
    _scanner.delegate = self;
    [_scanner startScanning];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [_scanner stopScanning];
    _scanner = nil;
}

- (void)beaconScanner:(ESSBeaconScanner *)scanner
        didFindBeacon:(id)beaconInfo {
    NSLog(@"I Saw an Eddystone!: %@", beaconInfo);
}

- (void)beaconScanner:(ESSBeaconScanner *)scanner didUpdateBeacon:(id)beaconInfo {
    NSLog(@"I Updated an Eddystone!: %@", beaconInfo);
    
    ESSBeaconInfo *BeaconInfo = beaconInfo;
    
    for (int i = 0; i < _mEddystoneBeaconDeviceList.count; i++) {
        ESSBeaconInfo *Beacon = [_mEddystoneBeaconDeviceList objectAtIndex:i];
        
        if ([Beacon.beaconID.beaconID isEqual:BeaconInfo.beaconID.beaconID]) {
            [_mEddystoneBeaconDeviceList replaceObjectAtIndex:i withObject:beaconInfo];
//            [self UpdateUiState:nil];
            [self performSelectorOnMainThread:@selector(UpdateUiState:) withObject:nil waitUntilDone:YES];
            return;
        }
    }
    
    [_mEddystoneBeaconDeviceList addObject:BeaconInfo];
    
    [self performSelectorOnMainThread:@selector(UpdateUiState:) withObject:nil waitUntilDone:YES];
//    [self UpdateUiState:nil];
}

-(void) UpdateUiState:(NSString*)str
{
    [self.EddyStoneTableView reloadData];
}

- (void)beaconScanner:(ESSBeaconScanner *)scanner didLoseBeacon:(id)beaconInfo
{
    NSLog(@"I Lost an Eddystone!: %@", beaconInfo);
}



#pragma mark - Table view data source

-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
    return _mEddystoneBeaconDeviceList.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @"Scanning...";
}


- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    
    cell = [tv dequeueReusableCellWithIdentifier:@"BeaconDeviceCell"];
    
    UILabel *namespaceID = (UILabel*)[cell viewWithTag:1];
    UILabel *instanceID = (UILabel*)[cell viewWithTag:2];
    
    UILabel *MeasuredPowerValue = (UILabel*)[cell viewWithTag:3];
    UILabel *rssi = (UILabel*)[cell viewWithTag:4];
    
    ESSBeaconInfo *temp = [_mEddystoneBeaconDeviceList objectAtIndex:indexPath.row];
    
    
    NSString *TEMPStr = [NSString stringWithFormat:@"%@", temp.beaconID.beaconID];
    TEMPStr = [TEMPStr stringByReplacingOccurrencesOfString:@"<" withString:@""];
    TEMPStr = [TEMPStr stringByReplacingOccurrencesOfString:@">" withString:@""];
    TEMPStr = [TEMPStr stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    
    namespaceID.text = [[TEMPStr uppercaseString] substringWithRange:NSMakeRange(0, 20)];
    instanceID.text = [[TEMPStr uppercaseString] substringWithRange:NSMakeRange(20, 12)];
    
    MeasuredPowerValue.text = [NSString stringWithFormat:@"%d", [temp.txPower intValue]];
    rssi.text = [NSString stringWithFormat:@"%d", [temp.RSSI intValue]];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView  deselectRowAtIndexPath:indexPath animated:YES];
}


@end
