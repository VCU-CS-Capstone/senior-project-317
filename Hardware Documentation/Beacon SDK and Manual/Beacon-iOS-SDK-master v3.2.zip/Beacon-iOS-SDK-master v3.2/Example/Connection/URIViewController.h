//
//  URIViewController.h
//  Example
//
//  Created by jaalee on 15/5/22.
//  Copyright (c) 2015年 jaalee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <JAALEEBeaconSDK/JAALEEBeaconIOSSDK.h>
#import "BaseViewController.h"

@interface URIViewController : BaseViewController
@end
