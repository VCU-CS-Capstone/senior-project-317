//
//  MainViewController.m
//  Example
//
//  Created by jaalee on 15/5/22.
//  Copyright (c) 2015年 jaalee. All rights reserved.
//

#import "MainViewController.h"

@interface MainViewController ()<JLEBeaconDeviceDelegate>
@property (weak, nonatomic) IBOutlet UIButton *mBtn_Motion;
@property (weak, nonatomic) IBOutlet UIButton *mBtn_Position;
@property (weak, nonatomic) IBOutlet UIButton *mBtn_Acc;
@property (weak, nonatomic) IBOutlet UIButton *mBtn_UriBeacon;
@property (weak, nonatomic) IBOutlet UIButton *mBtn_iBeacon;

@end

@implementation MainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    if (self.mSelectBeaconDevice) {
        self.mSelectBeaconDevice.delegate = self;
        [self.mSelectBeaconDevice connectToBeaconWithPassword:@"666666"];
        [WaitProgressShow showWithStatus:@"Trying to connect the Beacon..."];
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    if (self.mSelectBeaconDevice) {
        self.mSelectBeaconDevice.delegate = self;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - JLEBeaconDeviceDelegate Callbacks

- (void)beaconConnectionDidSucceeded:(JLEBeaconDevice *)beacon hardware:(JAALEE_BEACON_HARDWARE_VERSION)hardware
{
    self.mSelectBeaconDevice = beacon;
    
    NSLog(@"hardware, %ld", (long)hardware);
    
    if ([beacon isSupportButton]) {
        [beacon startNotifyJAALEEButton];
        [WaitProgressShow showSuccessWithStatus:@"Connected successfully & Start detect JAALEE Button" duration:4];
    }
    else
    {
        [WaitProgressShow showSuccessWithStatus:@"Connected successfully"];
    }
    
//    [beacon writeBeaconState:BEACON_STATE_IBEACON_NORMAL withCompletion:^(BOOL value, NSError*error)
//     {
//         if (value) {
//             NSLog(@"Success");
//         }
//         else
//         {
//             NSLog(@"%@", error);
//         }
//     }];
}

- (void)beaconConnectionDidFail:(JLEBeaconDevice *)beacon withError:(NSError *)error
{
    [WaitProgressShow showErrorWithStatus:@"Connect the beacon Failed"];
    [self.navigationController popToRootViewControllerAnimated:true];
}

- (void)beaconDidDisconnect:(JLEBeaconDevice *)beacon withError:(NSError *)error
{
    [WaitProgressShow showErrorWithStatus:@"Disconnect from the Beacon"];
    [self.navigationController popToRootViewControllerAnimated:true];
}

- (void)beaconDidButtonDetected:(JLEBeaconDevice *)beacon type:(JAALEE_BUTTON_TYPE)type
{
    if (type == JAALEE_BUTTON_TYPE_SINGLE) {
        [WaitProgressShow showSuccessWithStatus:@"Button single touched"];
    }
    else if (type == JAALEE_BUTTON_TYPE_LONG_PRESS)
    {
        [WaitProgressShow showSuccessWithStatus:@"Button long pressed"];
    }
}

- (IBAction)OnTouchMotion:(id)sender {
    if ([self.mSelectBeaconDevice isSupportDetectMotion]) {
        [self performSegueWithIdentifier:@"BeaconMotionDetect" sender:nil];
    }
    else
    {
        [WaitProgressShow showErrorWithStatus:@"Current device is not support detect motion"];
    }

}

- (IBAction)OnTouchPosition:(id)sender {
    
    if ([self.mSelectBeaconDevice isSupportDetectPosition]) {
        [self performSegueWithIdentifier:@"BeaconPositionDetect" sender:nil];
    }
    else
    {
        [WaitProgressShow showErrorWithStatus:@"Current device is not support detect position"];
    }
}

- (IBAction)OnTouchAcc:(id)sender {
    
    if ([self.mSelectBeaconDevice isSupportReadAccelerationValue]) {
        [self performSegueWithIdentifier:@"BeaconAccValueDetect" sender:nil];
    }
    else
    {
        [WaitProgressShow showErrorWithStatus:@"Current device is not support read acceleration value"];
    }
}

- (IBAction)OnTouchURIBeacon:(id)sender {
    if ([self.mSelectBeaconDevice isSupportEddystone]) {
        [self performSegueWithIdentifier:@"BeaconURIBeacon" sender:nil];
    }
    else
    {
        [WaitProgressShow showErrorWithStatus:@"Current device is not support eddystone"];
    }
    
}

- (IBAction)OnTouchiBeacon:(id)sender {
    [self performSegueWithIdentifier:@"BeaconIbeacon" sender:nil];
}
- (IBAction)OnTouchBeaconState:(id)sender {
    [self performSegueWithIdentifier:@"BeaconStateSetting" sender:nil];
}
- (IBAction)OnTouchConfigureBeaconAsEddyStone:(id)sender {
    
    if (![self.mSelectBeaconDevice isSupportEddystone]) {
        [WaitProgressShow showErrorWithStatus:@"Current device does not support Eddystone"];
        return;
    }
    
    [WaitProgressShow showWithStatus:@"Trying to enable eddystone mode"];
    
    [self.mSelectBeaconDevice configureCustomChannelAsEddyStoneUID:@"EBEFD08370A247C89837" InstanceID:@"E7B5634DF524" measuredPowerValue:-50 WithCompletion:^(BOOL value, NSError*error)
     {
         if (value) {
             NSLog(@"EddyStone configure Success");
             
             [self.mSelectBeaconDevice configureCustomChannelAlwaysBroadcast:false WithCompletion:^(BOOL value, NSError*error)
              {
                  if (value) {
                      NSLog(@"EddyStone mode enabled");
                      [WaitProgressShow dismiss];
                      UIAlertView *view = [[UIAlertView alloc] initWithTitle:@"Tip" message:@"EddyStone mode enabled" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
                      
                      [view show];
                      [self.navigationController popViewControllerAnimated:true];
                  }
                  else
                  {
                      NSLog(@"%@", error);
                      [WaitProgressShow showErrorWithStatus:@"EddyStone mode enable failed"];
                  }
              }];
         }
         else
         {
             NSLog(@"%@", error);
             [WaitProgressShow showErrorWithStatus:@"EddyStone mode enable failed"];
         }
     }];
    
    
//    [self.mSelectBeaconDevice configureCustomChannelAsiBeacon:@"EBEFD083-70A2-47C8-9837-E7B5634DF524" major:535 minor:535 measuredPowerValue:203 WithCompletion:^(BOOL value, NSError*error)
//     {
//         if (value) {
//             NSLog(@"Congifure custom channel as ibeacon successfully");
//             
//             [self.mSelectBeaconDevice configureCustomChannelAlwaysBroadcast:false WithCompletion:^(BOOL value, NSError*error)
//              {
//                  if (value) {
//                      NSLog(@"Custom channel adv iBeacon mode enabled");
//                      [WaitProgressShow dismiss];
//                      UIAlertView *view = [[UIAlertView alloc] initWithTitle:@"Tip" message:@"Custom channel adv ibeacon data enabled" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//                      
//                      [view show];
//                      [self.navigationController popViewControllerAnimated:true];
//                  }
//                  else
//                  {
//                      NSLog(@"%@", error);
//                      [WaitProgressShow showErrorWithStatus:@"configure failed"];
//                  }
//              }];
//         }
//         else
//         {
//             NSLog(@"%@", error);
//             [WaitProgressShow showErrorWithStatus:@"Congifure custom channel as ibeacon failed"];
//         }
//     }];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    BaseViewController *BaseView = (BaseViewController*) segue.destinationViewController;
    BaseView.mSelectBeaconDevice = self.mSelectBeaconDevice;
}

@end
