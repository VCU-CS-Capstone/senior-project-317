//
//  JLEURIBeaconDemo.h
//  Example
//
//  Created by jaalee on 15/5/19.
//  Copyright (c) 2015年 jaalee. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ViewController.h"

@interface JLEURIBeaconDemo : ViewController
@property (weak, nonatomic) IBOutlet UITableView *mTableView;
@end
