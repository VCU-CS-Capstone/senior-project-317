//
//  JLEBeacon.h
//  JaaleeBeaconSDK
//
//  Created by jaalee on 14-4-22.
//  Copyright (c) 2014年 jaalee. All rights reserved.
//

#import <CoreLocation/CoreLocation.h>

@interface JLEBeacon : CLBeacon

@end
