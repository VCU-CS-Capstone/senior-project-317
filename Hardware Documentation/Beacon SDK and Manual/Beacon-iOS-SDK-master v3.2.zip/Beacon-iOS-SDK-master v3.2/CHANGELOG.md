Jaalee Beacon makes life more simple and cheerful! If you are interested in our product, please contact us in following ways. We will provide the best service wholeheartedly for you!
For the latest information, please visit http://www.jaalee.com/International Sales: sales@ankhmaway.com.cnTechnology Support: service@jaalee.com

## 1.0 (April 25, 2014)
Features:

  - Ranging and monitoring Jaalee beacons
  - Beacon connection support 
  - Read/Write of Proximity UUID, Major, Minor, Measured Power, Broadcast Interval, Tx Power, Device Name.

## 2.0 (June 17, 2014)
Features:
  - Connect with password.
  - support jaalee new version of Beacon.
  - All the Jaalee Beacon are supported.
  - bug fix.
  
## 2.1 (August 25, 2014)
Features:
  - Fixes the bug that beacon name and broadcasting interval can not be read

## 2.2 (September 5, 2014)
Features:
  - Improve performance
  - Connect mode can be get

## 2.3 (October 13, 2014)
Features:
  - Support iOS 8.
  - Bug Fixes.

## 2.4 (October 14, 2014)
Features:
  - Bug Fixes.

## 2.4.1 (December 3, 2014)
Features:
  - Add Function.

## 2.4.2 (December 11, 2014)
Features:
  - Add Function to get local name.

## 2.4.3 (March 4, 2015)
Features:
  - Fix example bug of Notification.

## 2.5 (May 26, 2015)
Features:
  - Support URIBeacon.
  - Support JAALEE iB003-N
  - Support Motion Detect
  - Bugs fixes

## 2.6 (August 29, 2015)
Features:
  - Support EddyStone.

## 2.7 (September 25, 2015)
Features:
  - Support IOS 9.

## 3.0 (October 15, 2015)
Features:
  - Support Bitcode.
  - Support Framework.
  - Support Both iphoneos & iphonesimulator

## 3.2 (December 3, 2015)
Features:
  - Support JAALEE-OFA.
  - Custom channel can configure to adv beacon data.